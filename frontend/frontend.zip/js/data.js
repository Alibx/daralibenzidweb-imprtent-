// All data is now stored in PostgreSQL via the local API server.
// No localStorage is used for application data.
// The admin session is managed via sessionStorage (cleared on tab close).
export {};
